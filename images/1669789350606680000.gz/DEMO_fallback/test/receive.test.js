const { expect } = require('chai');
const { ethers } = require('hardhat'); // https://docs.ethers.io/v5/
const { loadFixture } = require("@nomicfoundation/hardhat-network-helpers");

describe('ReceiveEther Contract Test Suits', function () {

    // https://hardhat.org/tutorial/testing-contracts#reusing-common-test-setups-with-fixtures
    // loadFixture将在第一次运行设置，并在其他测试中快速返回到该状态。
    async function deployContractFixture() {
        const [owner, addr1] = await ethers.getSigners();
        const facotry = await ethers.getContractFactory("Callee");
        const contract = await facotry.deploy();
        return { contract, owner, addr1 };
    }

    it("测试纯转账", async function () {
        const { contract, owner, addr1 } = await loadFixture(deployContractFixture);

        let balance = await contract.getBalance();
        expect(balance).to.equal(0);

        //send ether to contract
        await owner.sendTransaction({
            to: contract.address,
            value: ethers.utils.parseEther("0.01"),
            gasLimit: 50000
        });

        balance = await contract.getBalance();
        expect(balance).to.equal(ethers.utils.parseEther("0.01"));
    });

    it("测试调用payable函数", async function () {
        const { contract, owner, addr1 } = await loadFixture(deployContractFixture);

        let balance = await contract.getBalance();
        expect(balance).to.equal(0);

        //call payable contract function
        await contract.giveMoney({ value: ethers.utils.parseEther("0.02") });

        balance = await contract.getBalance();
        expect(balance).to.equal(ethers.utils.parseEther("0.02"));
    });

});
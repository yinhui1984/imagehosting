const { expect } = require('chai');
const { ethers } = require('hardhat'); // https://docs.ethers.io/v5/
const { loadFixture } = require("@nomicfoundation/hardhat-network-helpers");

describe('Caller Contract Test Suits', function () {

    it("测试调用不存在的函数", async function () {
        let facotry = await ethers.getContractFactory("Caller");
        let callerContract = await facotry.deploy();

        facotry = await ethers.getContractFactory("Callee");
        let receiveContract = await facotry.deploy();

        await callerContract.callFunctionDoesNotExist(receiveContract.address);

    });

});